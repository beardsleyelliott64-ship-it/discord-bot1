import app from "./app";
import { logger } from "./lib/logger";
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const botPath = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "../discord-bot.cjs",
);
const botEnabled = Boolean(
  process.env["DISCORD_BOT_TOKEN"] || process.env["DISCORD_TOKEN"],
);
let botProcess: ReturnType<typeof spawn> | undefined;

if (botEnabled) {
  botProcess = spawn(process.execPath, [botPath], {
    stdio: "inherit",
    env: process.env,
  });
  botProcess.on("error", (err) =>
    logger.error({ err }, "Discord bot process error"),
  );
  botProcess.on("exit", (code, signal) => {
    if (code !== 0 && signal !== "SIGTERM") {
      logger.error({ code, signal }, "Discord bot stopped unexpectedly");
    }
  });
} else {
  logger.warn(
    "DISCORD_BOT_TOKEN is not configured; API started without the Discord bot",
  );
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});

function shutdown(signal: string) {
  logger.info({ signal }, "Shutting down");
  botProcess?.kill("SIGTERM");
  process.exit(0);
}

process.once("SIGTERM", () => shutdown("SIGTERM"));
process.once("SIGINT", () => shutdown("SIGINT"));
