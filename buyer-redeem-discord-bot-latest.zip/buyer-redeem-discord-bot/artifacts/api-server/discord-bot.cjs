require('dotenv').config();
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const {
  Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags,
  SlashCommandBuilder, REST, Routes, PermissionFlagsBits, ChannelType
} = require('discord.js');

const DISCORD_TOKEN = process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN;
const DISCORD_GUILD_ID = process.env.DISCORD_GUILD_ID || null;
const BUYER_ROLE_ID = process.env.BUYER_ROLE_ID;
const VERIFICATION_CHANNEL_ID = process.env.VERIFICATION_CHANNEL_ID || null;
const REDEEM_CHANNEL_ID = process.env.REDEEM_CHANNEL_ID || null;
const configuredVerificationRoleId = process.env.VERIFICATION_ROLE_ID || null;
function normalizeChannelName(name) {
  return name
    .toLowerCase()
    .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}
const buyerChannelNames = new Set(
  (process.env.BUYER_CHANNEL_NAMES || 'buyer-announcements,buyer-chat')
    .split(',')
    .map(name => normalizeChannelName(name.trim().replace(/^#/, '')))
    .filter(Boolean)
);
let verificationRoleId = configuredVerificationRoleId;
if (!DISCORD_TOKEN || !BUYER_ROLE_ID) {
  throw new Error('Missing DISCORD_BOT_TOKEN (or DISCORD_TOKEN) or BUYER_ROLE_ID in the environment.');
}

const DATA_DIR = path.join(__dirname, 'data');
const CODES_FILE = path.join(DATA_DIR, 'codes.json');
const GIVEAWAY_FILE = path.join(DATA_DIR, 'giveaway.json');
const REDEEM_PANEL_FILE = path.join(DATA_DIR, 'redeem-panels.json');
const VERIFICATION_PANEL_FILE = path.join(DATA_DIR, 'verification-panel.json');
const SUPPORT_PANEL_FILE = path.join(DATA_DIR, 'support-panel.json');
const GIVEAWAY_LENGTH_MS = 10 * 60 * 1000;
fs.mkdirSync(DATA_DIR, { recursive: true });

function readCodes() {
  try { return JSON.parse(fs.readFileSync(CODES_FILE, 'utf8')); }
  catch { return {}; }
}

function saveCodes(codes) {
  const temporary = `${CODES_FILE}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(codes, null, 2));
  fs.renameSync(temporary, CODES_FILE);
}

function readGiveawayConfig() {
  try {
    const config = JSON.parse(fs.readFileSync(GIVEAWAY_FILE, 'utf8'));
    return {
      enabled: Boolean(config.enabled),
      channelId: config.channelId || process.env.GIVEAWAY_CHANNEL_ID || null,
      minHours: Number(config.minHours) || 1,
      maxHours: Number(config.maxHours) || 3,
      nextAt: Number(config.nextAt) || null
    };
  } catch {
    return {
      enabled: Boolean(process.env.GIVEAWAY_CHANNEL_ID),
      channelId: process.env.GIVEAWAY_CHANNEL_ID || null,
      minHours: 1,
      maxHours: 3,
      nextAt: null
    };
  }
}

function saveGiveawayConfig(config) {
  const temporary = `${GIVEAWAY_FILE}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(config, null, 2));
  fs.renameSync(temporary, GIVEAWAY_FILE);
}

function readRedeemPanels() {
  try { return JSON.parse(fs.readFileSync(REDEEM_PANEL_FILE, 'utf8')); }
  catch { return {}; }
}

function saveRedeemPanels(panels) {
  const temporary = `${REDEEM_PANEL_FILE}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(panels, null, 2));
  fs.renameSync(temporary, REDEEM_PANEL_FILE);
}

function readVerificationPanel() {
  try { return JSON.parse(fs.readFileSync(VERIFICATION_PANEL_FILE, 'utf8')); }
  catch { return {}; }
}

function saveVerificationPanel(panel) {
  const temporary = `${VERIFICATION_PANEL_FILE}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(panel, null, 2));
  fs.renameSync(temporary, VERIFICATION_PANEL_FILE);
}

function readSupportPanel() {
  try { return JSON.parse(fs.readFileSync(SUPPORT_PANEL_FILE, 'utf8')); }
  catch { return {}; }
}

function saveSupportPanel(panel) {
  const temporary = `${SUPPORT_PANEL_FILE}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(panel, null, 2));
  fs.renameSync(temporary, SUPPORT_PANEL_FILE);
}

function createCode() {
  return `BUYER-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
}

function buildRedeemPanel() {
  const embed = new EmbedBuilder()
    .setColor(0x39d98a)
    .setTitle('Redeem your buyer code')
    .setDescription([
      'Have a buyer code? Claim your buyer role here.',
      '',
      '**How it works**',
      '1. Click **Redeem code**.',
      '2. Enter the code you received from staff.',
      '3. Your code is permanently linked to your Discord account.',
      '',
      'Each code works once and cannot be shared after redemption.'
    ].join('\n'))
    .setFooter({ text: 'Need a code? Contact the server staff.' });
  const button = new ButtonBuilder()
    .setCustomId('buyer_redeem:open')
    .setLabel('Redeem code')
    .setEmoji('🎁')
    .setStyle(ButtonStyle.Success);
  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(button)]
  };
}

function buildVerificationPanel() {
  const embed = new EmbedBuilder()
    .setColor(0x5b8cff)
    .setTitle('Server verification')
    .setDescription([
      'Welcome. Click the button below to verify your Discord account.',
      '',
      'Verification is instant and only needs to be completed once.',
      'If the button does not work, contact a member of staff.'
    ].join('\n'))
    .setFooter({ text: 'Verification is managed automatically.' });
  const button = new ButtonBuilder()
    .setCustomId('verification:complete')
    .setLabel('Verify me')
    .setEmoji('✅')
    .setStyle(ButtonStyle.Primary);
  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(button)]
  };
}

function buildSupportPanel() {
  const embed = new EmbedBuilder()
    .setColor(0x7c5cff)
    .setTitle('Support center')
    .setDescription([
      'Need a hand? Open a private support ticket and tell us what is going on.',
      '',
      '**Before opening a ticket**',
      '• Include the relevant order, product, or buyer-code details.',
      '• Never post passwords, tokens, or other private credentials.',
      '• Please keep one issue per ticket so staff can help quickly.',
      '',
      'A private ticket channel will be created for you and visible to you and staff.'
    ].join('\n'))
    .setFooter({ text: 'Support tickets are handled by the server team.' });
  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('support:open')
        .setLabel('Open a support ticket')
        .setEmoji('🛠️')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('support:rules')
        .setLabel('Support guidelines')
        .setEmoji('📖')
        .setStyle(ButtonStyle.Secondary)
    )]
  };
}

function buildTicketMessage(user, subject, details) {
  return {
    embeds: [new EmbedBuilder()
      .setColor(0x7c5cff)
      .setTitle(`Support ticket — ${subject}`)
      .setDescription(details)
      .addFields(
        { name: 'Opened by', value: `<@${user.id}>`, inline: true },
        { name: 'Status', value: 'Open', inline: true }
      )
      .setFooter({ text: 'Please use the button below when your issue is resolved.' })],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('support:close')
        .setLabel('Close ticket')
        .setEmoji('🔒')
        .setStyle(ButtonStyle.Danger)
    )]
  };
}

const commands = [
  new SlashCommandBuilder()
    .setName('setup-redeem')
    .setDescription('Post the buyer code redemption panel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('generate-code')
    .setDescription('Generate one-time buyer codes.')
    .addIntegerOption(option => option
      .setName('quantity')
      .setDescription('How many codes to create (1–20).')
      .setMinValue(1)
      .setMaxValue(20))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('redeem-status')
    .setDescription('Show code usage statistics.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('start-giveaways')
    .setDescription('Start buyer-code giveaways every 1–3 hours.')
    .addChannelOption(option => option
      .setName('channel')
      .setDescription('Channel where giveaways should be posted.')
      .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('stop-giveaways')
    .setDescription('Stop scheduled buyer-code giveaways.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('giveaway-status')
    .setDescription('Show the giveaway scheduler status.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
].map(command => command.toJSON());

// GuildMembers refreshes panels when members join; GuildMessages enables
// automatic replies inside private support tickets.
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});
let giveawayTimer = null;
let redeemPanelRefreshTimer = null;
let verificationPanelRefreshTimer = null;
const activeGiveaways = new Map();
const redeemingCodes = new Set();

client.once('clientReady', async () => {
  console.log(`Logged in as ${client.user.tag}`);
  const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);
  try {
    const route = DISCORD_GUILD_ID
      ? Routes.applicationGuildCommands(client.user.id, DISCORD_GUILD_ID)
      : Routes.applicationCommands(client.user.id);
    await rest.put(route, { body: commands });
    console.log(`${DISCORD_GUILD_ID ? 'Guild' : 'Global'} slash commands registered.`);
  } catch (error) {
    console.error('Could not register slash commands:', error.message);
    if (DISCORD_GUILD_ID) {
      try {
        await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
        console.warn('Registered global slash commands as a fallback; fix the configured guild access to make them appear immediately.');
      } catch (fallbackError) {
        console.error('Could not register global slash command fallback:', fallbackError.message);
      }
    }
  }
  console.log(`Accessible Discord servers: ${[...client.guilds.cache.values()].map(guild => `${guild.name} (${guild.id})`).join(', ') || 'none'}`);
  await verifyDiscordSetup();
  if (DISCORD_GUILD_ID) {
    redeemPanelRefreshTimer = setInterval(async () => {
      const guild = await client.guilds.fetch(DISCORD_GUILD_ID).catch(() => null);
      if (guild) await ensureRedeemPanel(guild);
    }, 5 * 60 * 1000);
    verificationPanelRefreshTimer = setInterval(async () => {
      const guild = await client.guilds.fetch(DISCORD_GUILD_ID).catch(() => null);
      if (guild) await ensureVerificationPanel(guild);
    }, 5 * 60 * 1000);
  }
  scheduleNextGiveaway();
});

async function verifyDiscordSetup() {
  if (!DISCORD_GUILD_ID) {
    console.warn('DISCORD_GUILD_ID is not set; the bot can connect, but role checks will happen per redemption.');
    return;
  }

  const guild = await client.guilds.fetch(DISCORD_GUILD_ID).catch(() => null);
  if (!guild) {
    console.error(`Discord setup failed: the bot cannot access guild ${DISCORD_GUILD_ID}. Check the server ID and reinvite with both bot and applications.commands scopes.`);
    return;
  }

  const role = await guild.roles.fetch(BUYER_ROLE_ID).catch(() => null);
  const botMember = await guild.members.fetchMe().catch(() => null);
  if (!role) {
    console.error(`Discord setup failed: buyer role ${BUYER_ROLE_ID} does not exist in ${guild.name}.`);
    return;
  }
  if (!botMember) {
    console.error(`Discord setup failed: could not fetch the bot member in ${guild.name}.`);
    return;
  }
  if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
    console.error('Discord setup failed: the bot is missing the Manage Roles permission.');
  } else if (role.position >= botMember.roles.highest.position) {
    console.error(`Discord setup failed: move the bot's highest role above ${role.name}.`);
  } else {
    console.log(`Discord setup verified for ${guild.name}; buyer role "${role.name}" is assignable.`);
  }
  await ensureRedeemPanel(guild);
  await ensureVerificationPanel(guild);
  await ensureSupportPanel(guild);
  await configureVerificationVisibility(guild);
}

async function ensureSupportPanel(guild) {
  const channel = guild.channels.cache.find(candidate =>
    candidate.isTextBased() && candidate.name.toLowerCase() === 'support'
  );
  if (!channel?.messages) {
    console.warn(`Support setup skipped: could not find a text channel named #support in ${guild.name}.`);
    return;
  }

  const panels = readSupportPanel();
  const recentMessages = await channel.messages.fetch({ limit: 100 }).catch(error => {
    console.error('Could not inspect support panel messages:', error.message);
    return new Map();
  });
  const panelMessages = [...recentMessages.values()]
    .filter(message => message.author?.id === client.user.id && isSupportPanelMessage(message))
    .sort((left, right) => right.createdTimestamp - left.createdTimestamp);
  let message = panels[guild.id]?.channelId === channel.id && panels[guild.id]?.messageId
    ? await channel.messages.fetch(panels[guild.id].messageId).catch(() => null)
    : null;
  if (!message || message.author?.id !== client.user.id || !isSupportPanelMessage(message)) {
    message = panelMessages[0] || null;
  }
  await Promise.all(panelMessages
    .filter(candidate => candidate.id !== message?.id)
    .map(candidate => candidate.delete('Remove duplicate support panels').catch(() => {})));
  if (message) {
    await message.edit(buildSupportPanel()).catch(error => {
      console.error('Could not refresh support panel:', error.message);
    });
  } else {
    message = await channel.send(buildSupportPanel()).catch(error => {
      console.error('Could not post support panel:', error.message);
      return null;
    });
  }
  if (message) {
    panels[guild.id] = { channelId: channel.id, messageId: message.id };
    saveSupportPanel(panels);
    console.log(`Support panel ready in #${channel.name}.`);
  }
}

function isSupportPanelMessage(message) {
  return Boolean(
    message.embeds?.some(embed => embed.title === 'Support center')
      || message.components?.some(row =>
        row.components?.some(component => component.customId === 'support:open')
      )
  );
}

async function ensureRedeemPanel(guild) {
  const panels = readRedeemPanels();
  const savedPanel = panels[guild.id];
  const channelId = REDEEM_CHANNEL_ID || savedPanel?.channelId;
  if (!channelId) {
    console.warn('REDEEM_CHANNEL_ID is not set and no saved redemption panel exists; automatic redemption panel is disabled.');
    return;
  }

  const channel = await guild.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased() || !channel.messages) {
    console.error(`Redemption setup failed: channel ${channelId} is missing or is not a text channel.`);
    return;
  }

  const recentMessages = await channel.messages.fetch({ limit: 100 }).catch(error => {
    console.error('Could not inspect buyer redemption panel messages:', error.message);
    return new Map();
  });
  const panelMessages = [...recentMessages.values()]
    .filter(message => message.author?.id === client.user.id && isRedeemPanelMessage(message))
    .sort((left, right) => right.createdTimestamp - left.createdTimestamp);

  let message = savedPanel?.channelId === channel.id && savedPanel.messageId
    ? await channel.messages.fetch(savedPanel.messageId).catch(() => null)
    : null;
  if (!message || message.author?.id !== client.user.id || !isRedeemPanelMessage(message)) {
    message = panelMessages[0] || null;
  }

  const duplicateMessages = panelMessages.filter(candidate => candidate.id !== message?.id);
  await Promise.all(duplicateMessages.map(candidate =>
    candidate.delete('Remove duplicate buyer redemption panel').catch(error => {
      console.error('Could not delete duplicate buyer redemption panel:', error.message);
    })
  ));

  if (message) {
    await message.edit(buildRedeemPanel()).catch(error => {
      console.error('Could not refresh buyer redemption panel:', error.message);
    });
  } else {
    message = await channel.send(buildRedeemPanel()).catch(error => {
      console.error('Could not post buyer redemption panel:', error.message);
      return null;
    });
  }
  if (message) {
    panels[guild.id] = { channelId: channel.id, messageId: message.id };
    saveRedeemPanels(panels);
    console.log(`Automatic redemption panel ready in #${channel.name}; it will refresh and recreate itself if deleted.`);
  }
}

function isRedeemPanelMessage(message) {
  return Boolean(
    message.embeds?.some(embed => embed.title === 'Redeem your buyer code')
      || message.components?.some(row =>
        row.components?.some(component => component.customId === 'buyer_redeem:open')
      )
  );
}

async function ensureVerificationPanel(guild) {
  if (!VERIFICATION_CHANNEL_ID) {
    console.warn('VERIFICATION_CHANNEL_ID is not set; automatic verification panel is disabled.');
    return;
  }

  const role = await getVerificationRole(guild);
  if (!role) {
    console.error(`Verification setup failed: could not find or create the Verified role in ${guild.name}.`);
    return;
  }
  const channel = await guild.channels.fetch(VERIFICATION_CHANNEL_ID).catch(() => null);
  if (!channel?.isTextBased() || !channel.messages) {
    console.error(`Verification setup failed: channel ${VERIFICATION_CHANNEL_ID} is missing or is not a text channel.`);
    return;
  }

  const panel = readVerificationPanel();
  const recentMessages = await channel.messages.fetch({ limit: 100 }).catch(error => {
    console.error('Could not inspect verification panel messages:', error.message);
    return new Map();
  });
  const panelMessages = [...recentMessages.values()]
    .filter(message => message.author?.id === client.user.id && isVerificationPanelMessage(message))
    .sort((left, right) => right.createdTimestamp - left.createdTimestamp);

  let message = panel.channelId === channel.id && panel.messageId
    ? await channel.messages.fetch(panel.messageId).catch(() => null)
    : null;
  if (!message || message.author?.id !== client.user.id || !isVerificationPanelMessage(message)) {
    message = panelMessages[0] || null;
  }

  const duplicateMessages = panelMessages.filter(candidate => candidate.id !== message?.id);
  await Promise.all(duplicateMessages.map(candidate =>
    candidate.delete('Remove duplicate verification panel').catch(error => {
      console.error('Could not delete duplicate verification panel:', error.message);
    })
  ));

  if (message) {
    await message.edit(buildVerificationPanel()).catch(error => {
      console.error('Could not refresh verification panel:', error.message);
    });
  } else {
    message = await channel.send(buildVerificationPanel()).catch(error => {
      console.error('Could not post verification panel:', error.message);
      return null;
    });
  }
  if (message) {
    saveVerificationPanel({ guildId: guild.id, channelId: channel.id, messageId: message.id });
    console.log(`Verification panel ready in #${channel.name}; clicking it grants "${role.name}".`);
  }
}

function isVerificationPanelMessage(message) {
  return Boolean(
    message.embeds?.some(embed => embed.title === 'Server verification')
      || message.components?.some(row =>
        row.components?.some(component => component.customId === 'verification:complete')
      )
  );
}

async function getVerificationRole(guild) {
  if (verificationRoleId) {
    return guild.roles.fetch(verificationRoleId).catch(() => null);
  }
  let role = guild.roles.cache.find(candidate => candidate.name.toLowerCase() === 'verified');
  if (!role) {
    role = await guild.roles.create({
      name: 'Verified',
      color: 0x5b8cff,
      reason: 'Automatic verification system role'
    }).catch(error => {
      console.error('Could not create the Verified role:', error.message);
      return null;
    });
  }
  if (role) verificationRoleId = role.id;
  return role;
}

function isBuyerChannel(channel) {
  return buyerChannelNames.has(normalizeChannelName(channel.name));
}

function isAdminLockedChannel(channel, everyoneRoleId) {
  if (hasEveryoneViewDeny(channel, everyoneRoleId)) return true;
  let parent = channel.parent;
  while (parent) {
    if (hasEveryoneViewDeny(parent, everyoneRoleId)) return true;
    parent = parent.parent;
  }
  return false;
}

async function configureVerificationVisibility(guild) {
  const verifiedRole = await getVerificationRole(guild);
  if (!verifiedRole) return;
  const everyoneRoleId = guild.roles.everyone.id;
  const channels = [...guild.channels.cache.values()]
    .filter(channel => !channel.isThread() && channel.permissionOverwrites);

  for (const channel of channels) {
    const isVerificationChannel = channel.id === VERIFICATION_CHANNEL_ID;
    const isBuyer = isBuyerChannel(channel);
    try {
      if (isVerificationChannel) {
        await channel.permissionOverwrites.edit(everyoneRoleId, { ViewChannel: true }, {
          reason: 'Public verification channel'
        });
        await channel.permissionOverwrites.edit(verifiedRole.id, { ViewChannel: true }, {
          reason: 'Verified members can return to verification'
        });
      } else {
        await channel.permissionOverwrites.edit(everyoneRoleId, { ViewChannel: false }, {
          reason: 'Hide channels until server verification'
        });
        if (isBuyer) {
          await channel.permissionOverwrites.edit(verifiedRole.id, { ViewChannel: false }, {
            reason: 'Buyer channels are not visible to verified-only members'
          });
        } else {
          await channel.permissionOverwrites.edit(verifiedRole.id, { ViewChannel: true }, {
            reason: 'Verified members can access normal channels'
          });
        }
        if (isBuyer) {
          await channel.permissionOverwrites.edit(BUYER_ROLE_ID, { ViewChannel: true }, {
            reason: 'Buyer role can access buyer channels'
          });
        }
      }
    } catch (error) {
      console.error(`Could not configure visibility for #${channel.name}:`, error.message);
    }
  }
  console.log(`Verification visibility configured; buyer-only channels: ${[...buyerChannelNames].join(', ')}`);
}

function managerOnly(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild);
}

function supportAutoReply(subject, details) {
  const question = `${subject} ${details}`.toLowerCase();
  if (/(invalid|not working|doesn't work|does not work|wrong).*(code|buyer)|\bcode\b.*(invalid|not working|wrong)/.test(question)) {
    return [
      'Here are the quickest checks for a buyer-code problem:',
      '1. Enter the code exactly as provided, including the `BUYER-` prefix.',
      '2. Make sure there are no extra spaces before or after it.',
      '3. If it says the code was already used, only staff can verify its history.',
      '4. If the buyer role cannot be assigned, staff may need to move the bot role above the buyer role.',
      '',
      'If those checks do not solve it, please leave the exact error message here for staff.'
    ].join('\n');
  }
  if (/(already used|redeemed|used code)/.test(question)) {
    return [
      'That code has already been redeemed. Buyer codes are one-time use and are permanently linked to the first Discord account that claims them.',
      'Please ask staff to check the redemption record rather than sharing the code publicly.'
    ].join('\n');
  }
  if (/(verify|verification|verified|verification role)/.test(question)) {
    return [
      'For verification, return to the `#verification` channel and click **Verify me**.',
      'If nothing happens, the bot may need its role moved higher than the Verified role, or staff may need to check its permissions.'
    ].join('\n');
  }
  if (/(buyer role|role|access|channel|can't see|cannot see|permission)/.test(question)) {
    return [
      'Access is controlled by your verification and buyer roles.',
      'Please complete verification first, then redeem your buyer code. If you still cannot see a buyer channel, tell staff which channel is missing and whether you can see your roles.'
    ].join('\n');
  }
  if (/(close|resolved|done|finished)/.test(question)) {
    return 'If your issue is resolved, use **Close ticket** above. Staff can reopen the conversation by creating a new ticket if needed.';
  }
  return [
    'Thanks for the details. I can help with common buyer-code, verification, and access issues.',
    'Please include the exact error message, the channel or feature affected, and what you tried already. A staff member will follow up here.'
  ].join('\n');
}

client.on('interactionCreate', async interaction => {
  if (interaction.isChatInputCommand()) {
    if (!managerOnly(interaction)) {
      return interaction.reply({ content: 'Only server managers can use this command.', flags: MessageFlags.Ephemeral });
    }

    if (interaction.commandName === 'setup-redeem') {
      const panels = readRedeemPanels();
      const existing = panels[interaction.guildId];
      let panelMessage = existing
        ? await interaction.channel.messages.fetch(existing.messageId).catch(() => null)
        : null;

      if (panelMessage) {
        await panelMessage.edit(buildRedeemPanel());
      } else {
        panelMessage = await interaction.channel.send(buildRedeemPanel());
      }

      panels[interaction.guildId] = {
        channelId: interaction.channelId,
        messageId: panelMessage.id
      };
      saveRedeemPanels(panels);
      return interaction.reply({ content: 'Buyer code panel posted.', flags: MessageFlags.Ephemeral });
    }

    if (interaction.commandName === 'generate-code') {
      const quantity = interaction.options.getInteger('quantity') || 1;
      const codes = readCodes();
      const generated = [];
      for (let index = 0; index < quantity; index++) {
        let code = createCode();
        while (codes[code]) code = createCode();
        codes[code] = { createdBy: interaction.user.id, createdAt: new Date().toISOString(), redeemed: false };
        generated.push(code);
      }
      saveCodes(codes);
      return interaction.reply({
        content: `Generated **${quantity}** one-time code(s):\n\`\`\`\n${generated.join('\n')}\n\`\`\`\nCopy these now — they will not be shown again by the bot.`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (interaction.commandName === 'redeem-status') {
      const codes = Object.values(readCodes());
      const redeemed = codes.filter(code => code.redeemed).length;
      return interaction.reply({
        content: `**${codes.length}** total code(s) · **${redeemed}** redeemed · **${codes.length - redeemed}** available`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (interaction.commandName === 'start-giveaways') {
      const channel = interaction.options.getChannel('channel');
      if (!channel.isTextBased()) {
        return interaction.reply({ content: 'Please choose a text channel.', flags: MessageFlags.Ephemeral });
      }
      const config = readGiveawayConfig();
      config.enabled = true;
      config.channelId = channel.id;
      config.minHours = 1;
      config.maxHours = 3;
      config.nextAt = Date.now() + randomDelay(config.minHours, config.maxHours);
      saveGiveawayConfig(config);
      scheduleNextGiveaway();
      return interaction.reply({
        content: `✅ Giveaways enabled in ${channel}. The first giveaway will start <t:${Math.floor(config.nextAt / 1000)}:R>. Each giveaway runs for 10 minutes.`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (interaction.commandName === 'stop-giveaways') {
      const config = readGiveawayConfig();
      config.enabled = false;
      config.nextAt = null;
      saveGiveawayConfig(config);
      if (giveawayTimer) clearTimeout(giveawayTimer);
      giveawayTimer = null;
      return interaction.reply({ content: '🛑 Scheduled giveaways stopped. An active giveaway, if any, remains open.', flags: MessageFlags.Ephemeral });
    }

    if (interaction.commandName === 'giveaway-status') {
      const config = readGiveawayConfig();
      const next = config.enabled && config.nextAt
        ? `<t:${Math.floor(config.nextAt / 1000)}:R>`
        : 'not scheduled';
      return interaction.reply({
        content: `**Giveaways:** ${config.enabled ? 'enabled' : 'disabled'}\n**Channel:** ${config.channelId ? `<#${config.channelId}>` : 'not set'}\n**Next giveaway:** ${next}\n**Interval:** ${config.minHours}–${config.maxHours} hours`,
        flags: MessageFlags.Ephemeral
      });
    }
  }

  if (interaction.isButton() && interaction.customId === 'buyer_redeem:open') {
    const modal = new ModalBuilder().setCustomId('buyer_redeem:submit').setTitle('Redeem your buyer code');
    const input = new TextInputBuilder()
      .setCustomId('buyer_code')
      .setLabel('Buyer code')
      .setPlaceholder('BUYER-XXXXXXXXXX')
      .setMinLength(6)
      .setMaxLength(32)
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    return interaction.showModal(modal.addComponents(new ActionRowBuilder().addComponents(input)));
  }

  if (interaction.isButton() && interaction.customId === 'support:open') {
    const modal = new ModalBuilder()
      .setCustomId('support:submit')
      .setTitle('Open a support ticket');
    const subject = new TextInputBuilder()
      .setCustomId('support_subject')
      .setLabel('What do you need help with?')
      .setPlaceholder('Example: Buyer code is not working')
      .setMinLength(3)
      .setMaxLength(45)
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    const details = new TextInputBuilder()
      .setCustomId('support_details')
      .setLabel('Tell us what happened')
      .setPlaceholder('Include useful details, but never share passwords or tokens.')
      .setMinLength(10)
      .setMaxLength(1000)
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    return interaction.showModal(modal.addComponents(
      new ActionRowBuilder().addComponents(subject),
      new ActionRowBuilder().addComponents(details)
    ));
  }

  if (interaction.isButton() && interaction.customId === 'support:rules') {
    return interaction.reply({
      content: [
        '**Support guidelines**',
        '• One issue per ticket, with enough detail for staff to reproduce it.',
        '• Never share passwords, payment details, bot tokens, or private keys.',
        '• Please be patient and keep replies in your ticket.',
        '• Close your ticket when the issue is resolved.'
      ].join('\n'),
      flags: MessageFlags.Ephemeral
    });
  }

  if (interaction.isModalSubmit() && interaction.customId === 'support:submit') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const subject = interaction.fields.getTextInputValue('support_subject').trim();
    const details = interaction.fields.getTextInputValue('support_details').trim();
    const guild = interaction.guild;
    if (!guild) return interaction.editReply({ content: 'This support panel can only be used inside the server.' });

    const existingTicket = guild.channels.cache.find(channel =>
      channel.isTextBased() && channel.topic === `support-ticket:${interaction.user.id}`
    );
    if (existingTicket) {
      return interaction.editReply({ content: `You already have an open ticket: ${existingTicket}.` });
    }

    const staffRoles = [...guild.roles.cache.values()]
      .filter(role => role.id !== guild.id && role.permissions.has(PermissionFlagsBits.ManageGuild))
      .map(role => ({
        id: role.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory
        ]
      }));
    try {
      const ticket = await guild.channels.create({
        name: `ticket-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 80) || `ticket-${interaction.user.id}`,
        type: ChannelType.GuildText,
        topic: `support-ticket:${interaction.user.id}`,
        parent: guild.channels.cache.find(channel =>
          channel.name.toLowerCase() === 'support' && channel.isTextBased()
        )?.parentId || undefined,
        permissionOverwrites: [
          {
            id: guild.id,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: interaction.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory
            ]
          },
          {
            id: client.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.ManageChannels
            ]
          },
          ...staffRoles
        ],
        reason: `Support ticket opened by ${interaction.user.tag}`
      });
      await ticket.send(buildTicketMessage(interaction.user, subject, details));
      await ticket.send({
        embeds: [new EmbedBuilder()
          .setColor(0x39d98a)
          .setTitle('Support assistant')
          .setDescription(supportAutoReply(subject, details))
          .setFooter({ text: 'This is an automatic first response. Staff can help with anything it cannot resolve.' })]
      });
      return interaction.editReply({ content: `Your private support ticket is ready: ${ticket}.` });
    } catch (error) {
      console.error('Could not create support ticket:', error.message);
      return interaction.editReply({ content: 'I could not create the ticket right now. Please contact staff directly.' });
    }
  }

  if (interaction.isButton() && interaction.customId === 'support:close') {
    const isTicket = interaction.channel?.topic === `support-ticket:${interaction.channel?.permissionOverwrites?.cache
      .filter(overwrite => overwrite.type === 1 && overwrite.id !== client.user.id)
      .first()?.id}`;
    if (!isTicket && !managerOnly(interaction)) {
      return interaction.reply({ content: 'Only the ticket owner or server staff can close this ticket.', flags: MessageFlags.Ephemeral });
    }
    await interaction.reply({ content: 'This ticket will be closed in a moment.', flags: MessageFlags.Ephemeral });
    setTimeout(() => interaction.channel?.delete('Support ticket closed').catch(() => {}), 1500);
    return;
  }

  if (interaction.isButton() && interaction.customId === 'verification:complete') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const role = await getVerificationRole(interaction.guild);
    const botMember = interaction.guild.members.me;
    if (!role) {
      return interaction.editReply({ content: '⚠️ The verification role is not configured correctly. Please contact staff.' });
    }
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageRoles)
      || role.position >= botMember.roles.highest.position) {
      return interaction.editReply({ content: '⚠️ Verification is temporarily unavailable because the bot cannot assign the role.' });
    }
    if (interaction.member.roles.cache.has(role.id)) {
      return interaction.editReply({ content: `✅ You are already verified and have the **${role.name}** role.` });
    }
    try {
      await interaction.member.roles.add(role, 'Completed automatic server verification');
      return interaction.editReply({ content: `✅ You are verified. Welcome — you now have the **${role.name}** role.` });
    } catch (error) {
      console.error('Could not assign verification role:', error.message);
      return interaction.editReply({ content: '❌ I could not complete verification. Please contact staff.' });
    }
  }

  if (interaction.isModalSubmit() && interaction.customId === 'buyer_redeem:submit') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const code = interaction.fields.getTextInputValue('buyer_code').trim().toUpperCase();
    if (redeemingCodes.has(code)) {
      return interaction.editReply({ content: '⏳ This code is already being processed. Try again in a moment.' });
    }
    redeemingCodes.add(code);

    try {
    const codes = readCodes();
    const record = codes[code];

    if (!record) return interaction.editReply({ content: '❌ That buyer code is invalid.' });
    if (record.redeemed) return interaction.editReply({ content: '❌ That buyer code has already been used.' });

    const role = interaction.guild.roles.cache.get(BUYER_ROLE_ID);
    const botMember = interaction.guild.members.me;
    if (!role) return interaction.editReply({ content: '⚠️ The configured buyer role does not exist.' });
    if (!botMember || role.position >= botMember.roles.highest.position) {
      return interaction.editReply({ content: '⚠️ Move the bot role above the buyer role in Server Settings → Roles.' });
    }
    if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.editReply({ content: '⚠️ I need the Manage Roles permission before I can grant access.' });
    }

    try {
      await interaction.member.roles.add(role, `Buyer code redeemed: ${code}`);
      record.redeemed = true;
      record.redeemedBy = interaction.user.id;
      record.redeemedAt = new Date().toISOString();
      saveCodes(codes);
      return interaction.editReply({ content: `✅ Code accepted. You now have the **${role.name}** role.` });
    } catch (error) {
      console.error('Could not assign buyer role:', error.message);
      return interaction.editReply({ content: '❌ I could not assign the buyer role. Please contact staff.' });
    }
    } finally {
      redeemingCodes.delete(code);
    }
  }

  if (interaction.isButton() && interaction.customId.startsWith('giveaway-entry:')) {
    const giveawayId = interaction.customId.split(':')[1];
    const giveaway = activeGiveaways.get(giveawayId);
    if (!giveaway) {
      return interaction.reply({ content: '❌ This giveaway has ended.', flags: MessageFlags.Ephemeral });
    }
    if (giveaway.entries.has(interaction.user.id)) {
      return interaction.reply({ content: 'You are already entered.', flags: MessageFlags.Ephemeral });
    }
    giveaway.entries.add(interaction.user.id);
    return interaction.reply({ content: '✅ You are entered. Good luck!', flags: MessageFlags.Ephemeral });
  }
});

client.on('guildMemberAdd', async member => {
  await ensureRedeemPanel(member.guild);
});

client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild || !message.channel?.isTextBased()) return;
  if (!message.channel.topic?.startsWith('support-ticket:')) return;
  const ownerId = message.channel.topic.slice('support-ticket:'.length);
  if (message.author.id !== ownerId) return;
  await message.channel.send({
    embeds: [new EmbedBuilder()
      .setColor(0x39d98a)
      .setTitle('Support assistant')
      .setDescription(supportAutoReply('Follow-up question', message.content))
      .setFooter({ text: 'Automatic guidance · staff can take over at any time.' })]
  }).catch(error => console.error('Could not send support assistant reply:', error.message));
});

client.on('error', error => console.error('Discord client error:', error));
client.login(DISCORD_TOKEN);

function randomDelay(minHours, maxHours) {
  const min = Math.max(1, Number(minHours) || 1);
  const max = Math.max(min, Number(maxHours) || 3);
  return (min + Math.random() * (max - min)) * 60 * 60 * 1000;
}

function scheduleNextGiveaway() {
  const config = readGiveawayConfig();
  if (!config.enabled || !config.channelId) return;
  if (giveawayTimer) clearTimeout(giveawayTimer);
  if (!config.nextAt || config.nextAt <= Date.now()) {
    config.nextAt = Date.now() + randomDelay(config.minHours, config.maxHours);
    saveGiveawayConfig(config);
  }
  const wait = Math.max(1000, config.nextAt - Date.now());
  giveawayTimer = setTimeout(async () => {
    try {
      const latest = readGiveawayConfig();
      if (latest.enabled) await runGiveaway(latest.channelId);
    } catch (error) {
      // A missing channel or temporary Discord error must not permanently
      // stop the scheduler.
      console.error('Giveaway run failed:', error.message);
    } finally {
      const updated = readGiveawayConfig();
      if (updated.enabled) {
        updated.nextAt = Date.now() + randomDelay(updated.minHours, updated.maxHours);
        saveGiveawayConfig(updated);
        scheduleNextGiveaway();
      }
    }
  }, wait);
  console.log(`Next giveaway scheduled for ${new Date(config.nextAt).toISOString()}`);
}

async function runGiveaway(channelId) {
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) {
    console.error(`Giveaway channel ${channelId} could not be found or is not text-based.`);
    return;
  }
  const giveawayId = crypto.randomBytes(6).toString('hex');
  let message;
  try {
    message = await channel.send({
      embeds: [new EmbedBuilder()
        .setColor(0xffc857)
        .setTitle('🎁 Buyer Code Giveaway')
        .setDescription('Click the button below to enter. One winner will receive a one-time buyer code by DM.\n\n**Entries close in 10 minutes.**')
        .setFooter({ text: 'Never share a code sent to you by the bot.' })],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`giveaway-entry:${giveawayId}`)
          .setLabel('Enter giveaway')
          .setEmoji('🎟️')
          .setStyle(ButtonStyle.Primary)
      )]
    });
  } catch (error) {
    console.error(`Could not post giveaway in channel ${channelId}:`, error.message);
    return;
  }
  const giveaway = { entries: new Set() };
  activeGiveaways.set(giveawayId, giveaway);
  setTimeout(() => finishGiveaway(giveawayId, message), GIVEAWAY_LENGTH_MS);
}

async function finishGiveaway(giveawayId, message) {
  const giveaway = activeGiveaways.get(giveawayId);
  if (!giveaway) return;
  activeGiveaways.delete(giveawayId);
  const entries = [...giveaway.entries];
  if (!entries.length) {
    return message.edit({
      content: 'No entries were received.',
      components: [],
      embeds: [new EmbedBuilder().setColor(0x6b7280).setTitle('🎁 Giveaway ended').setDescription('Nobody entered this giveaway.')]
    }).catch(() => {});
  }
  const winnerId = entries[crypto.randomInt(entries.length)];
  const codes = readCodes();
  let code = createCode();
  while (codes[code]) code = createCode();
  codes[code] = {
    createdBy: client.user.id,
    createdAt: new Date().toISOString(),
    source: 'giveaway',
    giveawayMessageId: message.id,
    redeemed: false
  };
  saveCodes(codes);
  const winner = await client.users.fetch(winnerId).catch(() => null);
  let delivered = false;
  if (winner) {
    delivered = Boolean(await winner.send(`🎉 You won the buyer-code giveaway!\n\nYour one-time code is: **${code}**\n\nRedeem it in the server’s buyer redemption panel.`).then(() => true).catch(() => false));
  }
  await message.edit({
    content: delivered ? `🎉 Giveaway ended — congratulations <@${winnerId}>! Check your DMs.` : `🎉 Giveaway ended — congratulations <@${winnerId}>! Please contact staff because I could not DM you.`,
    components: [],
    embeds: [new EmbedBuilder().setColor(0x39d98a).setTitle('🎁 Giveaway winner selected').setDescription(`${entries.length} entr${entries.length === 1 ? 'y' : 'ies'} received.`)]
  }).catch(() => {});
}