# Buyer Redeem Discord Bot

A Discord bot that verifies new members, redeems one-time buyer codes, assigns the buyer role, and runs optional buyer-code giveaways.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- The API service supervises the Discord bot child process.
- `artifacts/api-server/discord-bot.cjs` — Discord commands, verification, redemption, and giveaways
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required secret: `DISCORD_BOT_TOKEN`
- Required env: `DISCORD_GUILD_ID`, `BUYER_ROLE_ID`, `VERIFICATION_CHANNEL_ID`, `REDEEM_CHANNEL_ID`
- Optional env: `VERIFICATION_ROLE_ID`, `GIVEAWAY_CHANNEL_ID`, `BUYER_CHANNEL_NAMES`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/index.ts` — API startup and supervised Discord child process
- `artifacts/api-server/discord-bot.cjs` — bot behavior
- `artifacts/api-server/data/` — persistent one-time code and panel state

## Architecture decisions

- The bot runs as a child of the managed API service so it shares the project lifecycle and environment.
- Guild-scoped slash commands are used when `DISCORD_GUILD_ID` is configured.
- A code is marked redeemed only after the buyer role has been assigned successfully.
- Verification visibility is configured at startup while preserving existing administrator-locked channels.

## Product

- Staff can post a redemption panel and generate one-time buyer codes.
- The redemption panel is automatically posted, refreshed every five minutes, and recreated if deleted.
- Buyers redeem codes through a Discord modal and receive the configured buyer role.
- New members can verify through the automatic verification panel.
- Staff can enable scheduled giveaways that DM the winner a buyer code.

## User preferences

- Keep Discord credentials in Replit Secrets; never place tokens in source files or chat.

## Gotchas

- The bot must be invited with both `bot` and `applications.commands` scopes.
- The bot's highest role must be above both the buyer and verification roles and have Manage Roles.
- Do not delete `artifacts/api-server/data/codes.json`; it is the redemption ledger.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
